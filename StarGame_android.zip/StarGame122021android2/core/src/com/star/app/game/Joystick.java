package com.star.app.game;

import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.star.app.screen.utils.Assets;

public class Joystick extends Group {
    private Hero hero;
    private BitmapFont font24;
    private Vector2 tempVec;

    private final float JOYSTICK_SIZE = 200;
    private final float JOYSTICK_HALF_SIZE = JOYSTICK_SIZE / 2;
    private final float JOYSTICK_ACCELERATE_SIZE = JOYSTICK_SIZE * 0.3f;

    public Joystick(final Hero hero) {
        this.hero = hero;
        this.font24 = Assets.getInstance().getAssetManager().get("fonts/font24.ttf");
        this.tempVec = new Vector2();

        Skin skin = new Skin();
        skin.addRegions(Assets.getInstance().getAtlas());

        TextButton.TextButtonStyle textButtonStyle = new TextButton.TextButtonStyle();
        textButtonStyle.up = skin.getDrawable("shortButton");
        textButtonStyle.font = font24;
        skin.add("simpleSkin", textButtonStyle);

        ImageButton.ImageButtonStyle imageButtonStyle = new ImageButton.ImageButtonStyle();
        imageButtonStyle.up = skin.getDrawable("joystick");
        imageButtonStyle.down = skin.getDrawable("joystickDown");
        skin.add("joystick", imageButtonStyle);


        final TextButton btnHp = new TextButton("pause", textButtonStyle);
        btnHp.addListener(new ChangeListener() {
                              @Override
                              public void changed(ChangeEvent event, Actor actor) {
                                  hero.showShop();
                              }
                          }
        );

        btnHp.setPosition(1000, 600);
        this.addActor(btnHp);


        final ImageButton btnCircle = new ImageButton(skin, "joystick");
        btnCircle.addListener(new InputListener() {
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {

            }

            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {

            }

        });

        btnCircle.setBounds(20, 20, JOYSTICK_SIZE, JOYSTICK_SIZE);
        this.addActor(btnCircle);


        this.setPosition(0, 0);
        this.setVisible(true);
        skin.dispose();
    }
}
