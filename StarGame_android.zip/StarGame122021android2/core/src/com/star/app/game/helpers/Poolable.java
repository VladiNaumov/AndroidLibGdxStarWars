package com.star.app.game.helpers;

public interface Poolable {
    boolean isActive();
}
