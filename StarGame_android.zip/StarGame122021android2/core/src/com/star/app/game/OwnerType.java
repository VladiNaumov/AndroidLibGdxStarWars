package com.star.app.game;

public enum OwnerType {
    PLAYER, BOT
}
